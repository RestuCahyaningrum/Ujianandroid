# APLIKASI ANDROID
###### Aplikasi android sederhana untuk menampilkan inputan data kedalam listview

### Dibuat Oleh :
##### Mochamad Idris
### NIM
##### G.111.21.1989